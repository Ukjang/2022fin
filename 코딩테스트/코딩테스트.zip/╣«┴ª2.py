def solution(id_list, report, k):
    answer = []
    log_list = []
    su_dict = {}
    ban_list = []
    log_dict = {}
    for rep in report :
        # 신고 로그
        su_user = rep.split(' ')[0]
        ban_user = rep.split(' ')[1]
        # log list 생성
        log_list.append([su_user, ban_user])
    # 신고 중복 제거
    # log_list = set(log_list)
    # dict 형태로 만들어주기
    for log in log_list :
        if log[0] not in log_dict :
            log_dict[log[0]] = log[-1]
        else :
            log_li = log_dict[log[0]]
            log_dict[log[0]] = log_li + ' ' + log[1]
    # 로그딕트에 없으면 빈 []
    for id1 in id_list :
        if id1 not in log_dict:
            log_dict[id1] = 'null'


    # 전체 기준 신고 횟수 count
    for id1 in id_list:
        su_nm = 0
        for log in log_dict:
            if id1 in log_dict[log]:
                su_nm += 1
        su_dict[id1] = su_nm
    # 신고당한 내역이 없는 경우
    if id1 not in su_dict:
        su_dict[id1]  = 0
    # 밴 리스트에 추가
    for ba in su_dict :
        if su_dict[ba] >= k:
            ban_list.append(ba)
    # 메일 발송 횟수
    for us in id_list:
        mail_nm = 0
        for lo in log_dict[us].split(' '):
            try :
                if lo in ban_list:
                    mail_nm += 1
            except :
                pass
        answer.append(mail_nm)


    return answer

'''
값은 나오는데
채점 점수가.....................
눈물이 납니다
'''