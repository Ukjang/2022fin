def solution(n):
    answer = ''
    if n < 4 :
        return str(2**(n-1))
    if n % 3 != 0:
        answer = solution(n//3) + solution(n%3)
    else : 
        answer = solution(n//3-1) + solution(3)
    return answer