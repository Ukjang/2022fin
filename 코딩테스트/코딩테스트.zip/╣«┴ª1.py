def solution(lottos, win_nums):
    answer = []
    count_zero = 0
    correct_num = 0
    for i in lottos:
        if i != 0:
            if i in win_nums:
                correct_num += 1
        else :
            count_zero += 1
    max_output = correct_num + count_zero
    if max_output == 6:
        answer.append(1)
    elif max_output == 5:
        answer.append(2)
    elif max_output == 4:
        answer.append(3)
    elif max_output == 3:
        answer.append(4)
    elif max_output == 2:
        answer.append(5)
    else : 
        answer.append(6)
        
    if correct_num == 6:
        answer.append(1)
    elif correct_num == 5:
        answer.append(2)
    elif correct_num == 4:
        answer.append(3)
    elif correct_num == 3:
        answer.append(4)
    elif correct_num == 2:
        answer.append(5)
    else : 
        answer.append(6)
        
    
    return answer